/*
 * File:   main.c
 * Author: Afjal
 * Display digits 0?9 and 9?0 on Seven Segment (common cathode)
 * Using PIC16F877A, PORTD (RD0?RD6)
 */

#include <xc.h>
#define _XTAL_FREQ 20000000   // 20 MHz crystal

// CONFIGURATION BITS
#pragma config FOSC = HS    // High-speed oscillator
#pragma config WDTE = OFF   // Watchdog Timer disabled
#pragma config PWRTE = ON   // Power-up Timer enabled
#pragma config BOREN = ON   // Brown-out Reset enabled
#pragma config LVP = OFF    // Low-voltage programming disabled
#pragma config CPD = OFF    // Data EEPROM code protection off
#pragma config WRT = OFF    // Flash program memory write disabled
#pragma config CP = OFF     // Code protection off

/*
   Seven Segment (Common Cathode)
   Segment order mapping: a b c d e f g
   Digit patterns (0?9):

   0 -> 0x3F  // a,b,c,d,e,f
   1 -> 0x06  // b,c
   2 -> 0x5B  // a,b,d,e,g
   3 -> 0x4F  // a,b,c,d,g
   4 -> 0x66  // b,c,f,g
   5 -> 0x6D  // a,c,d,f,g
   6 -> 0x7D  // a,c,d,e,f,g
   7 -> 0x07  // a,b,c
   8 -> 0x7F  // a,b,c,d,e,f,g
   9 -> 0x6F  // a,b,c,d,f,g
*/

unsigned char digit_code[10] = {
    0x3F,  // 0
    0x06,  // 1
    0x5B,  // 2
    0x4F,  // 3
    0x66,  // 4
    0x6D,  // 5
    0x7D,  // 6
    0x07,  // 7
    0x7F,  // 8
    0x6F   // 9
};

void main(void) {
    TRISD = 0x00;  // PORTD as output
    PORTD = 0x00;  // clear initially

    while(1) {
        // Ascending: 0 ? 9
        for(int i=0; i<10; i++) {
            PORTD = digit_code[i];
            __delay_ms(500);
        }

       /*
       
        // Descending: 9 ? 0
        for(int i=9; i>=0; i--) {
            PORTD = digit_code[i];
            __delay_ms(500);

            if(i==0) break;  // ? stop when reaching 0 (to prevent infinite loop)
        }
        */
    }
}
